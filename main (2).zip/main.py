import csv
import pandas
import numpy
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgbm
import xgboost
from catboost import CatBoostClassifier
from sklearn.metrics import classification_report


class DiabeticModel:

    def __init__(self, csv_file_path):
        with open(csv_file_path, "r") as csv_file:
            self._df = pandas.read_csv(csv_file)
        self._new_features = []
        self._target_feature = None

    def _get_model_predictor_features(self):
        return ["age_continuous", "diag_1_desc", "max_glu_serum", "A1Cresult", "diabetesMed",
                "discharge_disposition_id_shrunk", "admission_source_id_shrunk", "medical_specialty", "race",
                 "health_state_count" ,"medication_instablity_count"]

    def _get_model_target_feature(self):
        return self._target_feature

    def _apply_modification_to_feature(self, original_feature, target_feature, modification_dict,
                                       add_as_a_new_feature=True):
        """
        Given an original feature column name, and rules to modify its existing value, the method
        will apply modification to the dataframe and place it under the target new feature
        """
        self._df[target_feature] = self._df[original_feature].apply(lambda x: modification_dict[x])

        if add_as_a_new_feature:
            self._new_features.append(target_feature)

    def _shrink_values_based_on_external_csv(self, original_feature, target_feature, csv_path):
        with open(csv_path, "r") as f:
            csv_file = csv.reader(f)
            column_value_converter = {int(num): processed_desc for [num, raw_desc, processed_desc] in csv_file}

            for k, v in column_value_converter.items():
                if v == "None":
                    column_value_converter[k] = numpy.nan

            self._apply_modification_to_feature(original_feature=original_feature,
                                                target_feature=target_feature,
                                                modification_dict=column_value_converter)

    def _delete_rows_from_df(self, lambda_criteria):
        """
        Delete rows from dataframe based in a predefined lambda criteria
        """
        self._df = self._df[lambda_criteria]

    def process_data(self, new_admission_source_id_values_csv_path, new_admission_type_id_values_csv_path,
                     new_discharge_disposition_id_values_csv_path):
        self._remove_patient_duplications()
        self._modify_question_marks_values_as_nan()
        self._add_is_sick_feature()
        self._add_continues_age()
        self._shrink_admission_source_id_values(
            new_admission_source_id_values_csv_path=new_admission_source_id_values_csv_path)
        self._shrink_admission_type_id_values(
            new_admission_type_id_values_csv_path=new_admission_type_id_values_csv_path)
        self._shrink_discharge_disposition_id_values(
            new_discharge_disposition_id_values_csv_path=new_discharge_disposition_id_values_csv_path)
        for diag_num in range(1, 4):
            self._convert_diag_features_number_to_description(target_diag_number=diag_num)
        self._add_new_medication_instability_and_health_state_features()

    def _remove_patient_duplications(self):
        self._df = self._df.sort_values(by="encounter_id")
        self._df = self._df.drop_duplicates(subset="patient_nbr", keep="first")

    def _modify_question_marks_values_as_nan(self):
        self._df = self._df.replace({"?": numpy.nan})

    def _add_is_sick_feature(self):
        """
        Define sickness for instances that readmitted after 30 days
        """
        target_feature = "is_sick"
        self._apply_modification_to_feature(original_feature="readmitted",
                                            target_feature=target_feature,
                                            modification_dict={"NO": False,
                                                               "<30": True,
                                                               ">30": False})
        # Define this new feature as the model's target feature
        self._target_feature = target_feature

    def _add_continues_age(self):
        """
         Create a new age feature as continuous parameter
        """
        self._apply_modification_to_feature(original_feature="age",
                                            target_feature="age_continuous",
                                            modification_dict=
                                            {'[0-10)': 10,
                                             '[10-20)': 20,
                                             '[20-30)': 30,
                                             '[30-40)': 40,
                                             '[40-50)': 50,
                                             '[50-60)': 60,
                                             '[60-70)': 70,
                                             '[70-80)': 80,
                                             '[80-90)': 90,
                                             '[90-100)': 100})

    def _add_boolean_age_post_60(self):
        """
        Create a new boolean age feature, 'True' if post 60, 'False' otherwise
        """
        self._apply_modification_to_feature(original_feature="age",
                                            target_feature="age_more_than_60",
                                            modification_dict=
                                            {'[0-10)': False,
                                             '[10-20)': False,
                                             '[20-30)': False,
                                             '[30-40)': False,
                                             '[40-50)': False,
                                             '[50-60)': False,
                                             '[60-70)': True,
                                             '[70-80)': True,
                                             '[80-90)': True,
                                             '[90-100)': True})

    def _shrink_admission_source_id_values(self, new_admission_source_id_values_csv_path):
        self._shrink_values_based_on_external_csv(original_feature="admission_source_id",
                                                  target_feature="admission_source_id_shrunk",
                                                  csv_path=new_admission_source_id_values_csv_path)

    def _shrink_admission_type_id_values(self, new_admission_type_id_values_csv_path):
        self._shrink_values_based_on_external_csv(original_feature="admission_type_id",
                                                  target_feature="admission_type_id_shrunk",
                                                  csv_path=new_admission_type_id_values_csv_path)

    def _shrink_discharge_disposition_id_values(self, new_discharge_disposition_id_values_csv_path):
        target_feature = "discharge_disposition_id_shrunk"
        self._shrink_values_based_on_external_csv(original_feature="discharge_disposition_id",
                                                  target_feature=target_feature,
                                                  csv_path=new_discharge_disposition_id_values_csv_path)
        # Some values (e.g., "Expired") will be entirely removed from dataframe
        self._delete_rows_from_df(lambda_criteria=lambda x: x[target_feature] != "DROP")

    def _convert_diag_features_number_to_description(self, target_diag_number):
        diag_feature = f"diag_{target_diag_number}"
        diag_desc_list = []

        for diag_value in self._df[diag_feature]:

            if diag_value is numpy.nan:
                diag_desc_list.append(numpy.nan)
                continue
            elif any(c.isalpha() for c in diag_value):
                # In case it has non-numerical char
                diag_value = -1
            else:
                # Cast value to float
                diag_value = float(diag_value)

            # Begin mapping
            if diag_value in list(range(390, 459)) + [785]:
                diag_desc_list.append("Circulatory")
            elif diag_value in list(range(460, 519)) + [786]:
                diag_desc_list.append("Respiratory")
            elif diag_value in list(range(520, 579)) + [787]:
                diag_desc_list.append("Digestive")
            elif diag_value >= 250 and diag_value < 251:
                diag_desc_list.append("Diabetes")
            elif diag_value in list(range(800, 999)):
                diag_desc_list.append("Injury")
            elif diag_value in list(range(710, 739)):
                diag_desc_list.append("Musculoskeletal")
            elif diag_value in list(range(580, 629)) + [788]:
                diag_desc_list.append("Genitourinary")
            elif diag_value in list(range(140, 239)):
                diag_desc_list.append("Neoplasms")
            else:
                diag_desc_list.append("Other")

        new_diag_feature = f"{diag_feature}_desc"
        self._df[new_diag_feature] = diag_desc_list
        self._new_features.append(new_diag_feature)

    def _add_new_medication_instability_and_health_state_features(self):
        # Exisitng features to be used to derive the new "medication instability count" feature
        medication_column = ['metformin', 'repaglinide', 'nateglinide', 'chlorpropamide', 'glimepiride',
                             'acetohexamide', 'glipizide', 'glyburide', 'tolbutamide', 'pioglitazone', 'rosiglitazone',
                             'acarbose', 'miglitol', 'troglitazone', 'tolazamide', 'examide', 'citoglipton', 'insulin',
                             'glyburide-metformin', 'glipizide-metformin', 'glimepiride-pioglitazone',
                             'metformin-rosiglitazone', 'metformin-pioglitazone']

        # Exisitng features to be used to derive the new "health state count" feature
        health_state = ["time_in_hospital", "num_procedures", "num_medications", "num_lab_procedures",
                        "number_diagnoses"]

        medication_instability_count_list = []
        health_state_count_list = []

        for (row_num, row) in self._df.iterrows():
            # Count the "Up"s and "Down"s of this patient
            medication_instablity_count = 0
            for med in medication_column:
                med_state = row[med]
                if med_state.lower() in ("up", "down"):
                    medication_instablity_count += 1
            medication_instability_count_list.append(medication_instablity_count)

            # Sum the features of health state, assumption is the higher the number,
            # then potentially the poorer health state
            health_state_count = 0
            for hs in health_state:
                health_state_count += row[hs]
            health_state_count_list.append(health_state_count)

        medication_instabilty_feature_name = "medication_instablity_count"
        health_state_feature_name = "health_state_count"

        for new_feature_name, feature_value_list in zip((medication_instabilty_feature_name, health_state_feature_name),
                                                        (medication_instability_count_list, health_state_count_list)):
            self._df[new_feature_name] = feature_value_list
            self._new_features.append(new_feature_name)

    def train_and_test_random_forest(self):
        features = pandas.get_dummies(self._df[self._get_model_predictor_features()])
        target = self._df[self._get_model_target_feature()]
        x_train, x_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
        random_forest_classifier = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42, class_weight="balanced")
        random_forest_classifier.fit(x_train, y_train)
        y_pred = random_forest_classifier.predict(x_test)
        accuracy = accuracy_score(y_test, y_pred)

        return accuracy, classification_report(y_test, y_pred)

    def tune_random_forest(self):
        from sklearn.model_selection import GridSearchCV
        features = pandas.get_dummies(self._df[self._get_model_predictor_features()])
        target = self._df[self._get_model_target_feature()]
        x_train, x_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

        param_grid = {
            'n_estimators': [100, 200],
            'max_depth': [None, 10, 20],
            'min_samples_split': [None, 2, 5],
            'min_samples_leaf': [None, 1, 2],
            'max_features': ['auto', 'sqrt'],
            'bootstrap': [True, False],
            'class_weight': ['balanced', ]
        }

        random_forest_classifier = RandomForestClassifier(random_state=42)
        grid_search = GridSearchCV(estimator=random_forest_classifier, param_grid=param_grid,
                                   scoring='accuracy', cv=5, n_jobs=-1, verbose=2)
        grid_search.fit(x_train, y_train)

        print(f"Best parameters found: {grid_search.best_params_}")

        best_rf_classifier = RandomForestClassifier(**grid_search.best_params_, random_state=42)
        best_rf_classifier.fit(x_train, y_train)

        y_pred = best_rf_classifier.predict(x_test)
        accuracy = accuracy_score(y_test, y_pred)

        return accuracy, classification_report(y_test, y_pred)

    def train_and_test_xgboost(self):
        features = pandas.get_dummies(self._df[self._get_model_predictor_features()])
        target = self._df[self._get_model_target_feature()]
        self._rename_columns(df=features)
        x_train, x_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
        ratio = len(y_train[y_train == 0]) / len(y_train[y_train == 1])
        xgboost_classifier = xgboost.XGBClassifier(n_estimators=100,
                                                   max_depth=3,
                                                   learning_rate=0.1,
                                                   random_state=42,
                                                   scale_pos_weight=ratio)
        xgboost_classifier.fit(x_train, y_train)
        y_pred = xgboost_classifier.predict(x_test)
        accuracy = accuracy_score(y_test, y_pred)
        return accuracy, classification_report(y_test, y_pred)

    def train_and_test_lgbm(self):
        features = pandas.get_dummies(self._df[self._get_model_predictor_features()])
        target = self._df[self._get_model_target_feature()]
        self._rename_columns(df=features)
        x_train, x_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
        lgb_params = {'objective': 'binary',
                      'metric': 'binary_logloss',
                      'boosting_type': 'gbdt',
                      'is_unbalance': True}

        lgbm_train = lgbm.Dataset(x_train, label=y_train)
        lgbm_test = lgbm.Dataset(x_test, label=y_test, reference=lgbm_train)
        num_round = 100
        bst = lgbm.train(lgb_params, lgbm_train, num_round, valid_sets=[lgbm_train, lgbm_test])

        y_pred = bst.predict(x_test, num_iteration=bst.best_iteration)
        accuracy = accuracy_score(y_test, (y_pred > 0.5).astype(int))

        return accuracy, classification_report(y_test, (y_pred > 0.5).astype(int))

    def train_and_test_catboost(self):
        features = pandas.get_dummies(self._df[self._get_model_predictor_features()])
        target = self._df[self._get_model_target_feature()]

        x_train, x_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

        model = CatBoostClassifier(iterations=1000,
                                   depth=6,
                                   learning_rate=0.1,
                                   loss_function='Logloss',
                                   random_seed=42,
                                   auto_class_weights="Balanced")

        model.fit(x_train, y_train)
        y_pred = model.predict(x_test)

        accuracy = accuracy_score(y_test, (y_pred == "True").astype(bool))

        return accuracy, classification_report(y_test, (y_pred == "True").astype(bool))

    def _rename_columns(self, df):
        """
         XGBoost returned some errors if the column names had '[', ']' or '<'
         Hence this method intended to rename such characters

         e.g.
             raise ValueError('feature_names must be string, and may not contain [, ] or <')
             ValueError: feature_names must be string, and may not contain [, ] or <

             raise LightGBMError(_LIB.LGBM_GetLastError().decode('utf-8'))
             lightgbm.basic.LightGBMError: Do not support special JSON characters in feature name.
        """
        # Replace certain characters since xgboost isn't accepting json characters
        columns_rename_dict = {}
        features_to_modify = [c for c in list(df) if "[" in c or "]" in c or "<" in c or ">" in c]
        for f in features_to_modify:
            if "[" in f:
                columns_rename_dict[f] = f.replace("[", "(")
            elif "]" in f:
                columns_rename_dict[f] = f.replace("]", ")")
            else:
                columns_rename_dict[f] = f.replace("<", "smaller_")
        df.rename(columns=columns_rename_dict, inplace=True)


if __name__ == '__main__':

    CSV_PATH = input("Enter diabetic_data.csv path")
    ADMISSION_SOURCE_ID_CSV_PATH = input("Enter admission_source_id.csv path")
    ADMISSION_TYPE_ID_CSV_PATH = input("Enter admission_type_id.csv path")
    DISCHARGE_DISPOSITION_ID_CSV_PATH = input("Enter discharge_disposition_id.csv path")

    dm = DiabeticModel(CSV_PATH)
    dm.process_data(new_admission_source_id_values_csv_path=ADMISSION_SOURCE_ID_CSV_PATH,
                    new_admission_type_id_values_csv_path=ADMISSION_TYPE_ID_CSV_PATH,
                    new_discharge_disposition_id_values_csv_path=DISCHARGE_DISPOSITION_ID_CSV_PATH)

    acc_results = []
    cls_results = []
    for func in ("train_and_test_random_forest", "train_and_test_catboost", "train_and_test_lgbm",
                 "train_and_test_xgboost", "tune_random_forest"):
        try:
            accuracy, cls_report = getattr(dm, func)()
            acc_results.append(f"{func} accuracy score is: {accuracy}")
            cls_results.append(f"{func} classification report:\n{cls_report}")
        except Exception as exp:
            print(f"{func} failed: {exp}")

    for r in acc_results:
        print(r)

    for c in cls_results:
        print(c)
